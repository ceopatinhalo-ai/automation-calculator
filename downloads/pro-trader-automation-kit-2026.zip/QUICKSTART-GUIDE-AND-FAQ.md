# 🚀 PRO TRADER & AUTOMATION STARTER KIT 2026
*Official Quickstart Guide & Zero-Touch Self-Serve Manual*

Welcome to the **AutoFlow Pro Kit**! This documentation covers step-by-step setup in under 3 minutes.

---

## ⚡ 1. HOW TO ADD PINE SCRIPTS TO TRADINGVIEW (60 SECONDS)

1. Open your chart on [TradingView.com](https://www.tradingview.com).
2. At the bottom toolbar of your screen, click **"Pine Editor"**.
3. Open any `.pine` file from your download bundle (`Pine-Script-Fair-Value-Gap-ICT.pine`, `Pine-Script-Liquidity-Sweep-SMC.pine`, or `Pine-Script-PropFirm-Risk-Manager.pine`).
4. Select all text (Cmd+A / Ctrl+A) and Copy.
5. In the Pine Editor, clear any default code and Paste.
6. Click the blue **"Add to chart"** button at the top right of the Pine Editor.
7. Click **"Save"** to store it in your personal indicators library.

---

## ⚡ 2. HOW TO IMPORT BLUEPRINTS INTO MAKE.COM (60 SECONDS)

1. Log into your [Make.com](https://www.make.com) dashboard.
2. Click **"Create a new scenario"** at the top right.
3. In the empty canvas, click the **Three Dots (...)** menu in the bottom controls bar.
4. Select **"Import Blueprint"**.
5. Choose `Kich-Ban-Gom-Lead-Telegram-Sheet-Make.json` from this package.
6. Click **Save** — all modules (Webhook, Google Sheets, Telegram Bot) will populate instantly. Connect your accounts and toggle the switch to **ON**.

---

## ⚡ 3. NOTION ULTIMATE TRADING JOURNAL ACCESS

- Open the Notion template link included in your purchase dashboard:
  👉 **Notion Pro Trading Journal:** `https://notion.so/templates/autoflow-pro-trading-journal-2026`
- Click **"Duplicate"** in the top-right corner to copy the database directly into your personal Notion workspace.

---

## 🛠️ FREQUENTLY ASKED QUESTIONS & TROUBLESHOOTING (FAQ)

**Q1: Do I need a paid TradingView account to use these Pine Scripts?**  
*A:* No! All scripts are built on Pine Script v5 and run 100% smoothly on the free plan of TradingView.

**Q2: I get an error "Compilation error: undeclared identifier" in TradingView. What should I do?**  
*A:* Ensure you copied the entire file including the first line `//@version=5`. Do not leave old code in the editor before pasting.

**Q3: Can I run the VPS script on Windows?**  
*A:* The `install-ai-agent-vps.sh` script is designed for Linux Ubuntu/Debian Cloud VPS (such as a $4.99/mo Hostinger VPS). If you are on Windows/Mac, deploy a VPS server first, SSH into it, and run the script there.

**Q4: Which brokers offer the lowest spreads for ICT & Scalping?**  
*A:* We recommend True ECN Raw Spread accounts with 0.0 pip spreads:
- **IC Markets Raw Spread:** https://icmarkets.com/?camp=38531
- **Exness Zero Spread:** https://one.exnesstrack.net/a/ulep7bti

---

## 📜 TERMS OF SALE & AS-IS DIGITAL LICENSE
This product is an instant digital download asset pack. It is provided "as-is" for self-study and automated execution. Due to the digital nature of source code and instant delivery, no 1-on-1 personalized coding support is included. All rights reserved by AutoFlow Tech 2026.
